//
//  ISBigoAdapter.h
//  ISBigoAdapter
//
//  Copyright © 2021-2025 Unity Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/LevelPlayBaseAdapter.h>
#import <IronSource/IronSource.h>

static NSString * const BigoAdapterVersion = @"5.8.0";
static NSString * Githash = @"663a9fb";

@interface ISBigoAdapter : LevelPlayBaseAdapter

@end
