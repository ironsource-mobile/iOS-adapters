//
//  ISBigoAdapter.h
//  ISBigoAdapter
//
//  Copyright © 2021-2025 Unity Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/LevelPlayBaseAdapter.h>
#import <IronSource/IronSource.h>

static NSString * const BigoAdapterVersion = @"5.13.0";
static NSString * Githash = @"195b112";

@interface ISBigoAdapter : LevelPlayBaseAdapter

@end
