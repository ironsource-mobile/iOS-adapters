//
//  ISBigoAdapter.h
//  ISBigoAdapter
//
//  Copyright © 2024 ironSource Mobile Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/ISBaseAdapter+Internal.h>

static NSString * const BigoAdapterVersion = @"4.3.2";
static NSString * Githash = @"fb0ba13";

@interface ISBigoAdapter : ISBaseAdapter

@end
