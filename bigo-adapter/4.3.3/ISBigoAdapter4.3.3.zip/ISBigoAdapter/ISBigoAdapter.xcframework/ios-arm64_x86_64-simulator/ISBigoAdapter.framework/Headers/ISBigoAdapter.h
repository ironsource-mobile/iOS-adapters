//
//  ISBigoAdapter.h
//  ISBigoAdapter
//
//  Copyright © 2024 ironSource Mobile Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/ISBaseAdapter+Internal.h>

static NSString * const BigoAdapterVersion = @"4.3.3";
static NSString * Githash = @"f948f27";

@interface ISBigoAdapter : ISBaseAdapter

@end
