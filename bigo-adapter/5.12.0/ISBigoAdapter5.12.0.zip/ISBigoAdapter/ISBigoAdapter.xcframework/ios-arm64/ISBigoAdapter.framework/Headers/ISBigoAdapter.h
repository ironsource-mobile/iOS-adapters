//
//  ISBigoAdapter.h
//  ISBigoAdapter
//
//  Copyright © 2021-2025 Unity Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/LevelPlayBaseAdapter.h>
#import <IronSource/IronSource.h>

static NSString * const BigoAdapterVersion = @"5.12.0";
static NSString * Githash = @"23ea61c";

@interface ISBigoAdapter : LevelPlayBaseAdapter

@end
