//
//  ISInMobiAdapter.h
//  ISInMobiAdapter
//
//  Copyright © 2021-2025 Unity Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/LevelPlayBaseAdapter.h>
#import <IronSource/IronSource.h>

static NSString * const InMobiAdapterVersion = @"5.8.0";
static NSString * Githash = @"0fb42d4";

// System Frameworks For InMobi Adapter
@import WebKit;

@interface ISInMobiAdapter : LevelPlayBaseAdapter

@end
