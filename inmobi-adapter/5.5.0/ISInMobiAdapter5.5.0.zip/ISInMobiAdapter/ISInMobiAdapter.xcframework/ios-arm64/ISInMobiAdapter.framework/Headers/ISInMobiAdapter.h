//
//  ISInMobiAdapter.h
//  ISInMobiAdapter
//
//  Copyright © 2021-2025 Unity Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/ISBaseAdapter+Internal.h>

static NSString * const InMobiAdapterVersion = @"5.5.0";
static NSString * Githash = @"34f0e73";
 
//System Frameworks For InMobi Adapter

@import WebKit;

@interface ISInMobiAdapter : ISBaseAdapter

@end
