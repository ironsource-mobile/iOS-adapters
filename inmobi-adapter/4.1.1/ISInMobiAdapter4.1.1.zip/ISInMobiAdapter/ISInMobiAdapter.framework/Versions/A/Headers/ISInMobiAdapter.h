//
//  ISInMobiAdapter.h
//  ISInMobiAdapter
//
//  Created by Yotam Ohayon on 26/10/2015.
//  Copyright © 2015 IronSource. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IronSource/ISBaseAdapter+Internal.h"

//System Frameworks For Inmobi Adapter

@import AdSupport;
@import AudioToolbox;
@import AVFoundation;
@import CoreTelephony;
@import CoreLocation;
@import EventKit;
@import EventKitUI;
@import Foundation;
@import MediaPlayer;
@import MessageUI;
@import StoreKit;
@import Social;
@import SystemConfiguration;
@import Security;
@import SafariServices;
@import UIKit;


@interface ISInMobiAdapter : ISBaseAdapter


@end
