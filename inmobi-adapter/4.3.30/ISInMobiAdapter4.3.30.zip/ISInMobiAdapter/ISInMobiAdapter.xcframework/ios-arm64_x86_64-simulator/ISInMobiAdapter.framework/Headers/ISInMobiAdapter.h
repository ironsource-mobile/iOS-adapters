//
//  ISInMobiAdapter.h
//  ISInMobiAdapter
//
//  Copyright © 2023 ironSource Mobile Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/ISBaseAdapter+Internal.h>

static NSString * const InMobiAdapterVersion = @"4.3.30";
static NSString * Githash = @"6d2ca53";
 
//System Frameworks For InMobi Adapter

@import WebKit;

@interface ISInMobiAdapter : ISBaseAdapter

@end
