//
//  ISInMobiAdapter.h
//  ISInMobiAdapter
//
//  Created by Yotam Ohayon on 26/10/2015.
//  Copyright © 2015 IronSource. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IronSource/ISBaseAdapter+Internal.h"

static NSString * const InMobiAdapterVersion = @"4.3.15";
static NSString * GitHash = @"d12363b1a";
 
//System Frameworks For InMobi Adapter

@import WebKit;

@interface ISInMobiAdapter : ISBaseAdapter


@end
