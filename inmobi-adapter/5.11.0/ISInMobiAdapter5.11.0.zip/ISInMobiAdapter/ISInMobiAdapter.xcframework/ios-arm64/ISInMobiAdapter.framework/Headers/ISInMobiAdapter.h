//
//  ISInMobiAdapter.h
//  ISInMobiAdapter
//
//  Copyright © 2021-2025 Unity Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/LevelPlayBaseAdapter.h>
#import <IronSource/IronSource.h>

static NSString * const InMobiAdapterVersion = @"5.11.0";
static NSString * Githash = @"c0912fd";

// System Frameworks For InMobi Adapter
@import WebKit;

@interface ISInMobiAdapter : LevelPlayBaseAdapter

@end
