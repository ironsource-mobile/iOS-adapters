//
//  ISSnapAdapter.h
//  ISSnapAdapter
//
//  Created by Yonti Makmel on 24/09/2019.
//

#import <Foundation/Foundation.h>
#import "IronSource/ISBaseAdapter+Internal.h"

static NSString * const SnapAdapterVersion = @"4.3.0";
static NSString * GitHash = @"e7b1473e2";

@import CoreFoundation;
@import StoreKit;

@interface ISSnapAdapter : ISBaseAdapter

@end
