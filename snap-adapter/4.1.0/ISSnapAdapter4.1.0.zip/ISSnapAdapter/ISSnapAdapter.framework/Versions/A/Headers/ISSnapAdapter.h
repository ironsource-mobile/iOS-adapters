//
//  ISSnapAdapter.h
//  ISSnapAdapter
//
//  Created by Yonti Makmel on 24/09/2019.
//

#import <Foundation/Foundation.h>
#import "IronSource/ISBaseAdapter+Internal.h"

static NSString * const SnapAdapterVersion = @"4.1.0";
static NSString * GitHash = @"d09426a71";

@import CoreFoundation;
@import StoreKit;

@interface ISSnapAdapter : ISBaseAdapter

@end
