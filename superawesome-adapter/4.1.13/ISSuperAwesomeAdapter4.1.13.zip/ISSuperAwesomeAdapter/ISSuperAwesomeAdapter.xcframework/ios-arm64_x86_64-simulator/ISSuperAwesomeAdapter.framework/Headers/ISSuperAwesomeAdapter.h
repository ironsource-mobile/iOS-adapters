//
//  ISSuperAwesomeAdapter.h
//  ISSuperAwesomeAdapter
//
//  Copyright © 2023 ironSource Mobile Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/ISBaseAdapter+Internal.h>

static NSString * const SuperAwesomeAdapterVersion = @"4.1.13";
static NSString * Githash = @"7e3361b";

@interface ISSuperAwesomeAdapter : ISBaseAdapter

@end
