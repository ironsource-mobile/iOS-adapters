//
//  ISSuperAwesomeAdapter.h
//  ISSuperAwesomeAdapter
//
//  Copyright © 2021-2025 Unity Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/ISBaseAdapter+Internal.h>

static NSString * const SuperAwesomeAdapterVersion = @"5.0.0";
static NSString * Githash = @"6f25002";

@interface ISSuperAwesomeAdapter : ISBaseAdapter

@end
