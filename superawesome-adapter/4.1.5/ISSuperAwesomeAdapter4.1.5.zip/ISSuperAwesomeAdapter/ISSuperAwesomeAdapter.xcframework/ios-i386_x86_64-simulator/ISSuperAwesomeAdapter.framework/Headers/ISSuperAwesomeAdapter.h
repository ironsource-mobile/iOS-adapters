//
//  ISSuperAwesomeAdapter.h
//  ISSuperAwesomeAdapter
//
//  Created by maoz.elbaz on 20/06/2021.
//

#import <Foundation/Foundation.h>
#import "IronSource/ISBaseAdapter+Internal.h"

static NSString * const SuperAwesomeAdapterVersion = @"4.1.5";
static NSString * GitHash = @"837bb6a95";
@interface ISSuperAwesomeAdapter : ISBaseAdapter

@end
