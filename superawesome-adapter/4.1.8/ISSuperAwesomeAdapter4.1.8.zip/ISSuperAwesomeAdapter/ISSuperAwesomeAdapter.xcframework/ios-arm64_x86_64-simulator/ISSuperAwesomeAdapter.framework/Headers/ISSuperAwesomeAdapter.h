//
//  ISSuperAwesomeAdapter.h
//  ISSuperAwesomeAdapter
//
//  Copyright © 2023 ironSource Mobile Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/ISBaseAdapter+Internal.h>

static NSString * const SuperAwesomeAdapterVersion = @"4.1.8";
static NSString * Githash = @"d386ef2";

@interface ISSuperAwesomeAdapter : ISBaseAdapter

@end
