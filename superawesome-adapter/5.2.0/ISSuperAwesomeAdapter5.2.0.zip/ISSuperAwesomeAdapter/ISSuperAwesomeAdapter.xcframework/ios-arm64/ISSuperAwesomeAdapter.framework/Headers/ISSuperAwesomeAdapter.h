//
//  ISSuperAwesomeAdapter.h
//  ISSuperAwesomeAdapter
//
//  Copyright © 2021-2025 Unity Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/LevelPlayBaseAdapter.h>
#import <IronSource/IronSource.h>

static NSString * const SuperAwesomeAdapterVersion = @"5.2.0";
static NSString * Githash = @"1d07bfd";

//System Frameworks For SuperAwesome Adapter

@interface ISSuperAwesomeAdapter : LevelPlayBaseAdapter

@end
