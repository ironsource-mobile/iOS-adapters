//
//  ISSuperAwesomeAdapter.h
//  ISSuperAwesomeAdapter
//
//  Created by maoz.elbaz on 20/06/2021.
//

#import <Foundation/Foundation.h>
#import "IronSource/ISBaseAdapter+Internal.h"

static NSString * const SuperAwesomeAdapterVersion = @"4.1.4";
static NSString * GitHash = @"7d03d75be";
@interface ISSuperAwesomeAdapter : ISBaseAdapter

@end
