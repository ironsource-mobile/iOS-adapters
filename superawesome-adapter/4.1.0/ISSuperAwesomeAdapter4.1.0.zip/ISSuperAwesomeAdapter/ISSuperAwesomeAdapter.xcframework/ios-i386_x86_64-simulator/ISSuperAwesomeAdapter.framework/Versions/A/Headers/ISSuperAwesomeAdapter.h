//
//  ISSuperAwesomeAdapter.h
//  ISSuperAwesomeAdapter
//
//  Created by maoz.elbaz on 20/06/2021.
//

#import <Foundation/Foundation.h>
#import "IronSource/ISBaseAdapter+Internal.h"

static NSString * const SuperAwesomeAdapterVersion = @"4.1.0";
static NSString * GitHash = @"f4bb09c3c";
@interface ISSuperAwesomeAdapter : ISBaseAdapter

@end
