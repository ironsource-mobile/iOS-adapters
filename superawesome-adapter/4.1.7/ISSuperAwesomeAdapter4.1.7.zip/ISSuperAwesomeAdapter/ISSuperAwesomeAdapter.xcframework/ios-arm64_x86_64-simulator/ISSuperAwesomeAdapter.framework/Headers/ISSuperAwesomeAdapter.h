//
//  ISSuperAwesomeAdapter.h
//  ISSuperAwesomeAdapter
//
//  Copyright © 2023 ironSource Mobile Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/ISBaseAdapter+Internal.h>

static NSString * const SuperAwesomeAdapterVersion = @"4.1.7";
static NSString * Githash = @"e2245c96f";

@interface ISSuperAwesomeAdapter : ISBaseAdapter

@end
