//
//  ISSuperAwesomeAdapter.h
//  ISSuperAwesomeAdapter
//
//  Copyright © 2023 ironSource Mobile Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/ISBaseAdapter+Internal.h>

static NSString * const SuperAwesomeAdapterVersion = @"4.1.11";
static NSString * Githash = @"cc6b950";

@interface ISSuperAwesomeAdapter : ISBaseAdapter

@end
