//
//  ISMobileFuseAdapter.h
//  ISMobileFuseAdapter
//
//  Copyright © 2021-2025 Unity Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/LevelPlayBaseAdapter.h>
#import <IronSource/IronSource.h>

static NSString * const mobileFuseAdapterVersion = @"5.5.0";
static NSString * Githash = @"870985c";

//No System Frameworks For MobileFuse Adapter are required

@interface ISMobileFuseAdapter : LevelPlayBaseAdapter

@end
