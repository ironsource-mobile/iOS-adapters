//
//  ISMobileFuseAdapter.h
//  ISMobileFuseAdapter
//
//  Copyright © 2024 ironSource Mobile Ltd. All rights reserved.
//
#import <Foundation/Foundation.h>
#import <IronSource/ISBaseAdapter+Internal.h>

static NSString * const mobileFuseAdapterVersion = @"4.3.6";
static NSString * Githash = @"1d6cab8";

//No System Frameworks For MobileFuse Adapter are required

@interface ISMobileFuseAdapter : ISBaseAdapter

@end
