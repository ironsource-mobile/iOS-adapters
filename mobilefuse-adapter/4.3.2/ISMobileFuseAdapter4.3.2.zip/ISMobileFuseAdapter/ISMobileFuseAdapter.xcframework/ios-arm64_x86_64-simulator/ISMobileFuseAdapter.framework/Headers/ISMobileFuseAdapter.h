//
//  ISMobileFuseAdapter.h
//  ISMobileFuseAdapter
//
//  Copyright © 2024 ironSource Mobile Ltd. All rights reserved.
//
#import <Foundation/Foundation.h>
#import <IronSource/ISBaseAdapter+Internal.h>

static NSString * const mobileFuseAdapterVersion = @"4.3.2";
static NSString * Githash = @"37a5a5b";

//No System Frameworks For MobileFuse Adapter are required

@interface ISMobileFuseAdapter : ISBaseAdapter

@end
