//
//  ISMobileFuseAdapter.h
//  ISMobileFuseAdapter
//
//  Copyright © 2021-2025 Unity Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/LevelPlayBaseAdapter.h>
#import <IronSource/IronSource.h>

static NSString * const mobileFuseAdapterVersion = @"5.7.0";
static NSString * Githash = @"c9424ae";

//No System Frameworks For MobileFuse Adapter are required

@interface ISMobileFuseAdapter : LevelPlayBaseAdapter

@end
