//
//  ISUnityAdsAdapter.h
//  ISUnityAdsAdapter
//
//  Copyright © 2021-2025 Unity Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/LevelPlayBaseAdapter.h>
#import <IronSource/IronSource.h>

static NSString * const UnityAdsAdapterVersion = @"5.13.0";
static NSString * Githash = @"97f9bae";

//System Frameworks For UnityAds Adapter
@import AdSupport;
@import CoreTelephony;
@import StoreKit;

@interface ISUnityAdsAdapter : LevelPlayBaseAdapter

@end
