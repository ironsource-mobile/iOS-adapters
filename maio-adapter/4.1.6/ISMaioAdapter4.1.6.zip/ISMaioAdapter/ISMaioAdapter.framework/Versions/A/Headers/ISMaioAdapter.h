//
//  ISMaioAdapter.h
//  ISMaioAdapter
//
//  Created by Dor Alon on 16/10/2017.
//  Copyright © 2017 IronSource. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IronSource/ISBaseAdapter+Internal.h"

static NSString * const MaioAdapterVersion = @"4.1.6";
static NSString * GitHash = @"cb32404f2";

//System Frameworks For Maio Adapter

@import AdSupport;
@import AVFoundation;
@import Foundation;
@import MobileCoreServices;
@import StoreKit;
@import SystemConfiguration;
@import UIKit;

@interface ISMaioAdapter : ISBaseAdapter

@end
