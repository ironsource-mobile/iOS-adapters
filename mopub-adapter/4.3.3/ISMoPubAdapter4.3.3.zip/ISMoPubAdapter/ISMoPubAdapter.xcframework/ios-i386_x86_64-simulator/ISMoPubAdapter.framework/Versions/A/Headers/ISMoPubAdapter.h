//
//  ISMoPubAdapter.h
//  ISMoPubAdapter
//
//  Created by maoz.elbaz on 16/03/2021.
//

#import <Foundation/Foundation.h>
#import "IronSource/ISBaseAdapter+Internal.h"


static NSString * const MoPubAdapterVersion = @"4.3.3";
static NSString * GitHash = @"917b282c8";


//System Frameworks For MoPub Adapter
@import AdSupport;
@import AVFoundation;
@import AVKit;
@import CoreGraphics;
@import CoreLocation;
@import CoreMedia;
@import CoreTelephony;
@import Foundation;
@import MediaPlayer;
@import QuartzCore;
@import SafariServices;
@import StoreKit;
@import SystemConfiguration;
@import UIKit;
@import WebKit;


@interface ISMoPubAdapter : ISBaseAdapter


@end
