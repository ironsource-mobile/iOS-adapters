//
//  ISMoPubAdapter.h
//  ISMoPubAdapter
//
//  Created by maoz.elbaz on 16/03/2021.
//

#import <Foundation/Foundation.h>
#import "IronSource/ISBaseAdapter+Internal.h"


static NSString * const MoPubAdapterVersion = @"4.3.1";
static NSString * GitHash = @"155715f00";


//System Frameworks For MoPub Adapter
@import AdSupport;
@import AVFoundation;
@import CoreGraphics;
@import CoreLocation;
@import CoreMedia;
@import CoreTelephony;
@import Foundation;
@import MediaPlayer;
@import MessageUI;
@import QuartzCore;
@import SafariServices;
@import StoreKit;
@import SystemConfiguration;
@import UIKit;
@import WebKit;


@interface ISMoPubAdapter : ISBaseAdapter


@end
