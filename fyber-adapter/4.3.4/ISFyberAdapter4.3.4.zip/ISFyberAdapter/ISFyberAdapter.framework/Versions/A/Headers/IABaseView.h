//
//  IABaseView.h
//  IASDKCore
//
//  Created by Inneractive on 09/09/2019.
//  Copyright © 2019 Inneractive. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface IABaseView : UIView

@end

NS_ASSUME_NONNULL_END
