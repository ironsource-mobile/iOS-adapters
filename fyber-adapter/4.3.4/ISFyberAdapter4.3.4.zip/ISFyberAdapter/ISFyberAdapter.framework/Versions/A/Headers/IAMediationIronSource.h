//
//  IAMediationIronSource.h
//  IASDKCore
//
//  Created by Avi Gelkop on 9/26/19.
//  Copyright © 2019 Inneractive. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "IAMediation.h"

@interface IAMediationIronSource : IAMediation

@end
