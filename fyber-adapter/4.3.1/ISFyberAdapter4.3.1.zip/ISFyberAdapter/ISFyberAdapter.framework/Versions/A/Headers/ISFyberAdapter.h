//
//  ISFyberAdapter.h
//  ISFyberAdapter
//
//  Created by Gili Ariel on 14/03/2018.
//  Copyright © 2018 Gili Ariel. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IronSource/ISBaseAdapter+Internal.h"

static NSString * const FyberAdapterVersion             = @"4.3.1";
static NSString *  GitHash = @"15106b4dd";

@import SystemConfiguration;
@import CoreGraphics;
@import EventKit;
@import EventKitUI;
@import MediaPlayer;
@import MessageUI;
@import CoreTelephony;
@import StoreKit;
@import AdSupport;
@import AVFoundation;
@import CoreMedia;
@import WebKit;
@import UIKit;
@import Foundation;


@interface ISFyberAdapter : ISBaseAdapter




@end
