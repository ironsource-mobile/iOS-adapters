//
//  ISFyberAdapter.h
//  ISFyberAdapter
//
//  Created by Gili Ariel on 14/03/2018.
//  Copyright © 2018 Gili Ariel. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IronSource/ISBaseAdapter+Internal.h"

@interface ISFyberAdapter : ISBaseAdapter




@end
