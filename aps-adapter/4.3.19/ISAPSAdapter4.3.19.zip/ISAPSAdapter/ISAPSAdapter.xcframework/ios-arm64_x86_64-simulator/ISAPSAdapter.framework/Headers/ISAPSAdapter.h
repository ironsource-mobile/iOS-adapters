//
//  ISAPSAdapter.h
//  ISAPSAdapter
//
//  Copyright © 2024 ironSource Mobile Ltd. All rights reserved.
//

#import <DTBiOSSDK/DTBiOSSDK.h>
#import <IronSource/ISBaseAdapter+Internal.h>
#import <IronSource/ISSetAPSDataProtocol.h>

static NSString *const APSAdapterVersion = @"4.3.19";
static NSString *Githash = @"a247a0e";

// System Frameworks For APS Adapter
@import CoreLocation;
@import CoreTelephony;
@import MediaPlayer;
@import StoreKit;
@import SystemConfiguration;
@import QuartzCore;

@interface ISAPSAdapter : ISBaseAdapter

+ (NSString *)getErrorFromCode:(DTBAdErrorCode)errorCode;

@end
