//
//  ISAPSAdapter.h
//  ISAPSAdapter
//
//  Copyright © 2024 ironSource Mobile Ltd. All rights reserved.
//

#import <IronSource/ISBaseAdapter+Internal.h>
#import <IronSource/ISSetAPSDataProtocol.h>
#import <DTBiOSSDK/DTBiOSSDK.h>

static NSString * const APSAdapterVersion = @"4.3.18";
static NSString * Githash = @"1f26f77";

//System Frameworks For APS Adapter
@import CoreLocation;
@import CoreTelephony;
@import MediaPlayer;
@import StoreKit;
@import SystemConfiguration;
@import QuartzCore;

@interface ISAPSAdapter : ISBaseAdapter

+ (NSString *)getErrorFromCode:(DTBAdErrorCode)errorCode;

@end

