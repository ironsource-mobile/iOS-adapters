//
//  ISAPSAdapter.h
//  ISAPSAdapter
//
//  Copyright © 2021-2025 Unity Technologies. All rights reserved.
//

#import <DTBiOSSDK/DTBiOSSDK.h>
#import <IronSource/ISBaseAdapter+Internal.h>
#import <IronSource/ISSetAPSDataProtocol.h>

static NSString *const APSAdapterVersion = @"4.3.21";
static NSString *Githash = @"5b0ce1a";

// System Frameworks For APS Adapter
@import CoreLocation;
@import CoreTelephony;
@import MediaPlayer;
@import StoreKit;
@import SystemConfiguration;
@import QuartzCore;

@interface ISAPSAdapter : ISBaseAdapter

+ (NSString *)getErrorFromCode:(DTBAdErrorCode)errorCode;

@end
