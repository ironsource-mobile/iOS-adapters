//
//  ISLiftoffAdapter.h
//  ISLiftoffAdapter
//
//  Copyright © 2023 ironSource Mobile Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/ISBaseAdapter+Internal.h>

static NSString * const LiftoffAdapterVersion = @"4.3.4";
static NSString * Githash = @"a4229ff49";

//No System Frameworks For Liftoff Adapter are required

@interface ISLiftoffAdapter : ISBaseAdapter

@end
