//
//  ISOguryAdapter.h
//  ISOguryAdapter
//
//  Copyright © 2021-2025 Unity Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/LevelPlayBaseAdapter.h>
#import <IronSource/IronSource.h>

static NSString * const OguryAdapterVersion = @"5.9.0";
static NSString * Githash = @"7ffea53";

@interface ISOguryAdapter : LevelPlayBaseAdapter

@end
