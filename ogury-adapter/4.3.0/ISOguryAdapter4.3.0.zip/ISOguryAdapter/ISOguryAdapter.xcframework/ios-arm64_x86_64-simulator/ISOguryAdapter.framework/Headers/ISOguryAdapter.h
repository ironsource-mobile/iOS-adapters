//
//  ISOguryAdapter.h
//  ISOguryAdapter
//
//  Copyright © 2024 ironSource Mobile Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/ISBaseAdapter+Internal.h>

static NSString * const oguryAdapterVersion = @"4.3.0";
static NSString * Githash = @"7a20e8e";

@interface ISOguryAdapter : ISBaseAdapter

@end
