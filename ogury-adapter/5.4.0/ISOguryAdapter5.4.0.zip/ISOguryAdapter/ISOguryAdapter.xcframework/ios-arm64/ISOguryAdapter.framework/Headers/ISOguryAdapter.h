//
//  ISOguryAdapter.h
//  ISOguryAdapter
//
//  Copyright © 2021-2025 Unity Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/ISBaseAdapter+Internal.h>

static NSString * const oguryAdapterVersion = @"5.4.0";
static NSString * Githash = @"7454676";

@interface ISOguryAdapter : ISBaseAdapter

@end
