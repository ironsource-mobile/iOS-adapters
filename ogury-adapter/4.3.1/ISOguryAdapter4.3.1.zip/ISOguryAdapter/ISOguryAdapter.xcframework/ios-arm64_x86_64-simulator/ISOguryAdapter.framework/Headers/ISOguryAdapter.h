//
//  ISOguryAdapter.h
//  ISOguryAdapter
//
//  Copyright © 2024 ironSource Mobile Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/ISBaseAdapter+Internal.h>

static NSString * const oguryAdapterVersion = @"4.3.1";
static NSString * Githash = @"34a3031";

@interface ISOguryAdapter : ISBaseAdapter

@end
