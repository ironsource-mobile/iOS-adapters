//
//  ISOguryAdapter.h
//  ISOguryAdapter
//
//  Copyright © 2021-2025 Unity Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/ISBaseAdapter+Internal.h>

static NSString * const oguryAdapterVersion = @"5.5.0";
static NSString * Githash = @"86f3fba";

@interface ISOguryAdapter : ISBaseAdapter

@end
