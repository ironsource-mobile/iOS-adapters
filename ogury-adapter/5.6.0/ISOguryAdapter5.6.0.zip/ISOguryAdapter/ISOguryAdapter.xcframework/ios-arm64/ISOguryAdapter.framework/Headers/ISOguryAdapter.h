//
//  ISOguryAdapter.h
//  ISOguryAdapter
//
//  Copyright © 2021-2025 Unity Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/LevelPlayBaseAdapter.h>
#import <IronSource/IronSource.h>

static NSString * const OguryAdapterVersion = @"5.6.0";
static NSString * Githash = @"99f289e";

@interface ISOguryAdapter : LevelPlayBaseAdapter

@end
