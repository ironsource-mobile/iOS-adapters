//
//  ISLineAdapter.h
//  ISLineAdapter
//
//  Copyright © 2021-2025 Unity Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/ISBaseAdapter+Internal.h>
#import <FiveAd/FiveAd.h>

static NSString * const LineAdapterVersion = @"5.0.0";
static NSString * Githash = @"6f25002";

//System Frameworks For LineAdapter
@import AdSupport;
@import AVFoundation;
@import AppTrackingTransparency;
@import AudioToolbox;
@import CoreMedia;
@import CoreTelephony;
@import Network;
@import StoreKit;
@import WebKit;

@interface ISLineAdapter : ISBaseAdapter

- (FADAdLoader *)getAdLoader:(NSString *)appId;

@end
