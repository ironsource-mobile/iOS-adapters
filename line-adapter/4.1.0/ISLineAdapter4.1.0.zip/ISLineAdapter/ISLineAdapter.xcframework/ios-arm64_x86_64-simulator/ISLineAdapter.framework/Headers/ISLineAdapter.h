//
//  ISLineAdapter.h
//  ISLineAdapter
//
//  Copyright © 2025 ironSource Mobile Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/ISBaseAdapter+Internal.h>
#import <FiveAd/FiveAd.h>

static NSString * const LineAdapterVersion = @"4.1.0";
static NSString * Githash = @"0633c22";

//System Frameworks For LineAdapter
@import AdSupport;
@import AVFoundation;
@import AppTrackingTransparency;
@import AudioToolbox;
@import CoreMedia;
@import CoreTelephony;
@import Network;
@import StoreKit;
@import WebKit;

@interface ISLineAdapter : ISBaseAdapter

- (FADAdLoader *)getAdLoader:(NSString *)appId;

@end
