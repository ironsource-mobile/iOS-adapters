//
//  ISBidMachineAdapter.h
//  ISBidMachineAdapter
//
//  Copyright © 2021-2025 Unity Technologies. All rights reserved.
//

#import <IronSource/LevelPlayBaseAdapter.h>
#import <IronSource/IronSource.h>

static NSString * const BidMachineAdapterVersion = @"5.11.0";
static NSString * Githash = @"2454e7e";

// No System Frameworks For BidMachine Adapter are required

@interface ISBidMachineAdapter : LevelPlayBaseAdapter

@end
