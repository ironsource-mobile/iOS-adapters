//
//  ISBidMachineAdapter.h
//  ISBidMachineAdapter
//
//  Copyright © 2021-2025 Unity Technologies. All rights reserved.
//

#import <IronSource/ISBaseAdapter+Internal.h>

static NSString * const BidMachineAdapterVersion = @"5.3.0";
static NSString * Githash = @"79b017b";

//No System Frameworks For BidMachine Adapter are required

@interface ISBidMachineAdapter : ISBaseAdapter

@end
