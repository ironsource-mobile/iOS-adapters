//
//  ISBidMachineAdapter.h
//  ISBidMachineAdapter
//
//  Copyright © 2021-2025 Unity Technologies. All rights reserved.
//

#import <IronSource/ISBaseAdapter+Internal.h>

static NSString * const BidMachineAdapterVersion = @"5.4.0";
static NSString * Githash = @"26fce7a";

//No System Frameworks For BidMachine Adapter are required

@interface ISBidMachineAdapter : ISBaseAdapter

@end
