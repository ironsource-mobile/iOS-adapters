//
//  ISBidMachineAdapter.h
//  ISBidMachineAdapter
//
//  Copyright © 2021-2025 Unity Technologies. All rights reserved.
//

#import <IronSource/ISBaseAdapter+Internal.h>

static NSString * const BidMachineAdapterVersion = @"4.3.20";
static NSString * Githash = @"2f9766a";

//No System Frameworks For BidMachine Adapter are required

@interface ISBidMachineAdapter : ISBaseAdapter

@end
