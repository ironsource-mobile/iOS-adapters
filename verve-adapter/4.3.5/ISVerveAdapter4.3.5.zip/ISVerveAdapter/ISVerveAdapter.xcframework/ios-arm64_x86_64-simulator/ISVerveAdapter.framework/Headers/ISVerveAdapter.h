//
//  ISVerveAdapter.h
//  ISVerveAdapter
//
//  Copyright © 2024 ironSource Mobile Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/ISBaseAdapter+Internal.h>

static NSString * const VerveAdapterVersion = @"4.3.5";
static NSString * Githash = @"97b1990";

//System Frameworks For VerveAdapter

@interface ISVerveAdapter : ISBaseAdapter

@end
