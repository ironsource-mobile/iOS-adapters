//
//  ISVerveAdapter.h
//  ISVerveAdapter
//
//  Copyright © 2021-2025 Unity Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/LevelPlayBaseAdapter.h>
#import <IronSource/IronSource.h>

static NSString * const VerveAdapterVersion = @"5.5.0";
static NSString * Githash = @"8d1dc21";

// System Frameworks For Verve Adapter

@interface ISVerveAdapter : LevelPlayBaseAdapter

@end
