//
//  ISVerveAdapter.h
//  ISVerveAdapter
//
//  Copyright © 2021-2025 Unity Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/ISBaseAdapter+Internal.h>

static NSString * const VerveAdapterVersion = @"5.3.0";
static NSString * Githash = @"761e294";

//System Frameworks For VerveAdapter

@interface ISVerveAdapter : ISBaseAdapter

@end
