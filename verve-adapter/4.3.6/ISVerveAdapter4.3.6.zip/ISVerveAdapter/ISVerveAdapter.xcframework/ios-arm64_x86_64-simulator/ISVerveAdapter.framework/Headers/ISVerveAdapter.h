//
//  ISVerveAdapter.h
//  ISVerveAdapter
//
//  Copyright © 2024 ironSource Mobile Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/ISBaseAdapter+Internal.h>

static NSString * const VerveAdapterVersion = @"4.3.6";
static NSString * Githash = @"1661aa3";

//System Frameworks For VerveAdapter

@interface ISVerveAdapter : ISBaseAdapter

@end
