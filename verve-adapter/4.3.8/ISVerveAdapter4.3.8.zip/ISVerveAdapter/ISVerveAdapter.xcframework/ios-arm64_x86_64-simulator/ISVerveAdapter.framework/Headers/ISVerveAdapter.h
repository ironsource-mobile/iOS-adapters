//
//  ISVerveAdapter.h
//  ISVerveAdapter
//
//  Copyright © 2021-2025 Unity Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/ISBaseAdapter+Internal.h>

static NSString * const VerveAdapterVersion = @"4.3.8";
static NSString * Githash = @"c64b3eb";

//System Frameworks For VerveAdapter

@interface ISVerveAdapter : ISBaseAdapter

@end
