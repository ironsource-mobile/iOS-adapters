//
//  ISYahooAdapter.h
//  ISYahooAdapter
//
//  Copyright © 2023 ironSource Mobile Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/ISBaseAdapter+Internal.h>

static NSString * const YahooAdapterVersion = @"4.3.5";
static NSString * Githash = @"a4229ff49";

//No System Frameworks For Yahoo Adapter are required

@interface ISYahooAdapter : ISBaseAdapter

@end
