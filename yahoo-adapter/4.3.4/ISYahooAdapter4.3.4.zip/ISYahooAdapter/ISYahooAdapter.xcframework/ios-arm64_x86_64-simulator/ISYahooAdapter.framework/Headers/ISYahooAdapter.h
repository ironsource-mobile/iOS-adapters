//
//  ISYahooAdapter.h
//  ISYahooAdapter
//
//  Copyright © 2022 ironSource Mobile Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IronSource/ISBaseAdapter+Internal.h"

static NSString * const YahooAdapterVersion = @"4.3.4";
static NSString * GitHash = @"f82c10fcf";

//No System Frameworks For Yahoo Adapter are required

@interface ISYahooAdapter : ISBaseAdapter

@end
