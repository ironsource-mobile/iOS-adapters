//
//  ISSmaatoAdapter.h
//  ISSmaatoAdapter
//
//  Copyright © 2021-2025 Unity Technologies. All rights reserved.
//

#import <IronSource/ISBaseAdapter+Internal.h>

static NSString * const SmaatoAdapterVersion = @"5.3.0";
static NSString * Githash = @"b70ba18";

//System Frameworks For Smaato Adapter
@import AdSupport;
@import AVFoundation;
@import CoreMedia;
@import CoreTelephony;
@import StoreKit;
@import SafariServices;
@import SystemConfiguration;
@import WebKit;

@interface ISSmaatoAdapter : ISBaseAdapter

@end
