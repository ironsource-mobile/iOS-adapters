//
//  ISSmaatoAdapter.h
//  ISSmaatoAdapter
//
//  Copyright © 2021-2025 Unity Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/LevelPlayBaseAdapter.h>
#import <IronSource/IronSource.h>

static NSString * const SmaatoAdapterVersion = @"5.7.0";
static NSString * Githash = @"82bad5a";

//System Frameworks For Smaato Adapter
@import AdSupport;
@import AVFoundation;
@import CoreMedia;
@import CoreTelephony;
@import StoreKit;
@import SafariServices;
@import SystemConfiguration;
@import WebKit;

@interface ISSmaatoAdapter : LevelPlayBaseAdapter

@end
