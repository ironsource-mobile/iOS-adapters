//
//  ISSmaatoAdapter.h
//  ISSmaatoAdapter
//
//  Copyright © 2024 ironSource Mobile Ltd. All rights reserved.
//

#import <IronSource/ISBaseAdapter+Internal.h>

static NSString * const SmaatoAdapterVersion = @"4.3.14";
static NSString * Githash = @"617c16b";

//System Frameworks For Smaato Adapter
@import AdSupport;
@import AVFoundation;
@import CoreMedia;
@import CoreTelephony;
@import StoreKit;
@import SafariServices;
@import SystemConfiguration;
@import WebKit;

@interface ISSmaatoAdapter : ISBaseAdapter

@end
