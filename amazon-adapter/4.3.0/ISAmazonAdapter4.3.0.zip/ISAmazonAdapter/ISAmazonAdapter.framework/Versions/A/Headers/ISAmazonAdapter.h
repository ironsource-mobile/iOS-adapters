//
//  ISAmazonAdapter.h
//  ISAmazonAdapter
//
//  Created by Guy Lis on 25/03/2019.
//


#import <Foundation/Foundation.h>
#import "IronSource/ISBaseAdapter+Internal.h"

static NSString * const AmazonAdapterVersion             = @"4.3.0";

@import AdSupport;
@import CoreLocation;
@import SystemConfiguration;
@import CoreTelephony;
@import MediaPlayer;
@import EventKit;
@import EventKitUI;
@import StoreKit;
@import QuartzCore;
@import JavaScriptCore;
@import SafariServices;

@interface ISAmazonAdapter : ISBaseAdapter

@end
