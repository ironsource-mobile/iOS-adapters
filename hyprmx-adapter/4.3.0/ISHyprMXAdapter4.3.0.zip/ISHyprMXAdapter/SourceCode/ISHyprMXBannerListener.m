//
//  ISHyprMXBannerListener.m
//  ISHyprMXAdapter
//
//  Created by Hadar Pur on 08/05/2022.
//  Copyright © 2022 ironSource. All rights reserved.
//

#import "ISHyprMXBannerListener.h"

@implementation ISHyprMXBannerListener

- (instancetype)initWithPropertyId:(NSString *)propertyId
                       andDelegate:(id<ISHyprMXBannerDelegateWrapper>)delegate {
    self = [super init];
    if (self) {
        _propertyId = propertyId;
        _delegate = delegate;
    }
    return self;
}

-(void)adDidLoad:(HyprMXBannerView *)bannerView {
    [_delegate adDidLoadWithBannerView:bannerView
                         andPropertyId:_propertyId];
}

-(void)adFailedToLoad:(HyprMXBannerView *)bannerView error:(NSError *)error {
    [_delegate adFailedToLoadWithBannerView:bannerView
                                 propertyId:_propertyId
                                   andError:error];
}

-(void)adDidOpen:(HyprMXBannerView *)bannerView {
    [_delegate adDidOpenWithBannerView:bannerView
                         andPropertyId:_propertyId];
}

-(void)adDidClose:(HyprMXBannerView *)bannerView {
    [_delegate adDidCloseWithBannerView:bannerView
                          andPropertyId:_propertyId];
}

-(void)adWasClicked:(HyprMXBannerView *)bannerView {
    [_delegate adWasClickedWithBannerView:bannerView
                            andPropertyId:_propertyId];
}

-(void)adWillLeaveApplication:(HyprMXBannerView *)bannerView {
    [_delegate adWillLeaveApplicationWithBannerView:bannerView
                                      andPropertyId:_propertyId];
}

@end
