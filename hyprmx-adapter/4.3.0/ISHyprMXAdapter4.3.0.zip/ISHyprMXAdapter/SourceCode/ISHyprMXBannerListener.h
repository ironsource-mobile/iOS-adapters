//
//  ISHyprMXBannerListener.h
//  ISHyprMXAdapter
//
//  Created by Hadar Pur on 08/05/2022.
//  Copyright © 2022 ironSource. All rights reserved.
//

#import <HyprMX/HyprMX.h>
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol ISHyprMXBannerDelegateWrapper <NSObject>

-(void)adDidLoadWithBannerView:(HyprMXBannerView *)bannerView
                 andPropertyId:(NSString *)propertyId;
-(void)adFailedToLoadWithBannerView:(HyprMXBannerView *)bannerView
                         propertyId:(NSString *)propertyId
                           andError:(NSError *)error;
-(void)adDidOpenWithBannerView:(HyprMXBannerView *)bannerView
                 andPropertyId:(NSString *)propertyId;
-(void)adDidCloseWithBannerView:(HyprMXBannerView *)bannerView
                  andPropertyId:(NSString *)propertyId;
-(void)adWasClickedWithBannerView:(HyprMXBannerView *)bannerView
                    andPropertyId:(NSString *)propertyId;
-(void)adWillLeaveApplicationWithBannerView:(HyprMXBannerView *)bannerView
                              andPropertyId:(NSString *)propertyId;

@end

@interface ISHyprMXBannerListener : NSObject <HyprMXBannerDelegate>

@property (nonatomic, strong) NSString* propertyId;
@property (nonatomic, weak) id<ISHyprMXBannerDelegateWrapper> delegate;

- (instancetype)initWithPropertyId:(NSString *)propertyId
                       andDelegate:(id<ISHyprMXBannerDelegateWrapper>)delegate;

@end


NS_ASSUME_NONNULL_END
