//
//  Copyright (c) 2015 IronSource. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IronSource/ISBaseAdapter+Internal.h"

static NSString * const HyprMXAdapterVersion = @"4.1.2";

//System Frameworks For HyprMX Adapter

@import MediaPlayer;
@import SafariServices;
@import Accelerate;
@import MessageUI;
@import CoreFoundation;
@import EventKit;
@import Social;
@import UIKit;
@import MessageUI;
@import SafariServices;

@interface ISHyprMXAdapter : ISBaseAdapter

@end
