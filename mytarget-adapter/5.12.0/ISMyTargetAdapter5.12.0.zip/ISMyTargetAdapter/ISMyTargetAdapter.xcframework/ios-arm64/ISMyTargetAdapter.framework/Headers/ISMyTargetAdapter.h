//
//  ISMyTargetAdapter.h
//  ISMyTargetAdapter
//
//  Copyright © 2021-2025 Unity Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/LevelPlayBaseAdapter.h>
#import <IronSource/IronSource.h>

static NSString * const MyTargetAdapterVersion = @"5.12.0";
static NSString * Githash = @"cc0ba50";

// System Frameworks For MyTarget Adapter
@import AdSupport;
@import AVFoundation;
@import CoreGraphics;
@import CoreMedia;
@import CoreTelephony;
@import SafariServices;
@import StoreKit;
@import SystemConfiguration;

@interface ISMyTargetAdapter : LevelPlayBaseAdapter

@end
