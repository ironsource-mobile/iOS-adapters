//
//  ISMyTargetAdapter.h
//  ISMyTargetAdapter
//
//  Copyright © 2023 ironSource Mobile Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/ISBaseAdapter+Internal.h>

static NSString * const MyTargetAdapterVersion = @"4.1.26";
static NSString * Githash = @"de54921";

//System Frameworks For MyTarget Adapter
@import AdSupport;
@import AVFoundation;
@import CoreGraphics;
@import CoreMedia;
@import CoreTelephony;
@import SafariServices;
@import StoreKit;
@import SystemConfiguration;


@interface ISMyTargetAdapter : ISBaseAdapter

@end
