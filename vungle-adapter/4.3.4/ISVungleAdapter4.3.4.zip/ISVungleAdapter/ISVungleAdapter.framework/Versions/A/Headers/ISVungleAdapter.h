//
//  Copyright (c) 2015 IronSource. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IronSource/ISBaseAdapter+Internal.h"

static NSString * const VungleAdapterVersion = @"4.3.4";
static NSString * GitHash = @"8ff077a51";

//System Frameworks For Vungle Adapter

@import CoreFoundation;
@import Foundation;
@import StoreKit;

@interface ISVungleAdapter : ISBaseAdapter

@end
