//
//  Copyright (c) 2015 IronSource. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IronSource/ISBaseAdapter+Internal.h"

static NSString * const VungleAdapterVersion         = @"4.1.7";
static NSString *  GitHash = @"9abf92dc3";


//System Frameworks For Vungle Adapter

@import CoreFoundation;
@import Foundation;
@import StoreKit;


@interface ISVungleAdapter : ISBaseAdapter

@end
