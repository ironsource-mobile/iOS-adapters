//
//  Copyright (c) 2015 IronSource. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IronSource/ISBaseAdapter+Internal.h"

static NSString * const VungleAdapterVersion = @"4.3.5";
static NSString * GitHash = @"5cd09079e";

//System Frameworks For Vungle Adapter

@import CoreFoundation;
@import Foundation;
@import StoreKit;

@interface ISVungleAdapter : ISBaseAdapter

@end
