//
//  Copyright (c) 2015 IronSource. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IronSource/ISBaseAdapter+Internal.h"

static NSString * const VungleAdapterVersion = @"4.3.2";
static NSString * GitHash = @"cdaf18438";

//System Frameworks For Vungle Adapter

@import CoreFoundation;
@import Foundation;
@import StoreKit;

@interface ISVungleAdapter : ISBaseAdapter

@end
