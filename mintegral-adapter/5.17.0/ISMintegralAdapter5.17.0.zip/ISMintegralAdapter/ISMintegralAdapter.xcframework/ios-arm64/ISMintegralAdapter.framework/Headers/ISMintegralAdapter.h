//
//  ISMintegralAdapter.h
//  ISMintegralAdapter
//
//  Copyright © 2021-2025 Unity Technologies. All rights reserved.
//

#import <IronSource/ISBaseAdapter+Internal.h>

static NSString * const MintegralAdapterVersion = @"5.17.0";
static NSString * Githash = @"43a7d8c";

//System Frameworks For Mintegral Adapter

@import AdSupport;
@import AVFoundation;
@import CoreGraphics;
@import CoreTelephony;
@import Foundation;
@import MobileCoreServices;
@import QuartzCore;
@import StoreKit;
@import UIKit;
@import WebKit;
          

@interface ISMintegralAdapter : ISBaseAdapter

@end

