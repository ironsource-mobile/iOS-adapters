//
//  ISMintegralAdapter.h
//  ISMintegralAdapter
//
//  Copyright © 2021-2025 Unity Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IronSource/LevelPlayBaseAdapter.h>
#import <IronSource/IronSource.h>

static NSString * const MintegralAdapterVersion = @"5.19.0";
static NSString * Githash = @"b55d972";

// System Frameworks For Mintegral Adapter
@import AdSupport;
@import AVFoundation;
@import CoreGraphics;
@import CoreTelephony;
@import MobileCoreServices;
@import QuartzCore;
@import StoreKit;
@import UIKit;
@import WebKit;

@interface ISMintegralAdapter : LevelPlayBaseAdapter

@end
