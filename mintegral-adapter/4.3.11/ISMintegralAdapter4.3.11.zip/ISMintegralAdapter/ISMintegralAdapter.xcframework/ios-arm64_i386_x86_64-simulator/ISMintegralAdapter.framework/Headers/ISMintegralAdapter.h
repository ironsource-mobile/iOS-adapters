//
//  ISMintegralAdapter.h
//  ISMintegralAdapter
//
//  Copyright © 2022 IronSource. All rights reserved.
//



#import "IronSource/ISBaseAdapter+Internal.h"

static NSString * const MintegralAdapterVersion = @"4.3.11";
static NSString * GitHash = @"ef4c3b31b";

//System Frameworks For Mintegral Adapter

@import AdSupport;
@import AVFoundation;
@import CoreGraphics;
@import CoreTelephony;
@import Foundation;
@import MobileCoreServices;
@import QuartzCore;
@import StoreKit;
@import UIKit;
@import WebKit;
          

@interface ISMintegralAdapter : ISBaseAdapter

@end

